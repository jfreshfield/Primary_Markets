// JavaScript Document

 $(".feat1").hover(function() {
                $('.feat1c').show();
                $('.feat1d').hide();
            }, function() {
                $('.feat1c').hide();
                $('.feat1d').show();
            });
            $(".feat2").hover(function() {
                $('.feat2c').show();
                $('.feat2d').hide();
            }, function() {
                $('.feat2c').hide();
                $('.feat2d').show();
            });
            $(".feat3").hover(function() {
                $('.feat3c').show();
                $('.feat3d').hide();
            }, function() {
                $('.feat3c').hide();
                $('.feat3d').show();
            });
            $(".feat4").hover(function() {
                $('.feat4c').show();
                $('.feat4d').hide();
            }, function() {
                $('.feat4c').hide();
                $('.feat4d').show();
            });
            $(".feat5").hover(function() {
                $('.feat5c').show();
                $('.feat5d').hide();
            }, function() {
                $('.feat5c').hide();
                $('.feat5d').show();
            });
            $(".feat6").hover(function() {
                $('.feat6c').show();
                $('.feat6d').hide();
            }, function() {
                $('.feat6c').hide();
                $('.feat6d').show();
            });